CREATE TABLE foo
(
  name character varying(255) NOT NULL,
  username character varying(255)
)
WITH (
  OIDS=FALSE
);