<?php
class FooController extends CExtController
{
    public function actionIndex()
    {
        $this->render('index');
    }
    // other actions
}
